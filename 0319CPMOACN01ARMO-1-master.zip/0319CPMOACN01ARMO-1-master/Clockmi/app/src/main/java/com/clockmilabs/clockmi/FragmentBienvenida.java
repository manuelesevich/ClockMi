package com.clockmilabs.clockmi;


import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import static com.clockmilabs.clockmi.MainActivity.TAG_NO_FRAGMENT_INICIO;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentBienvenida extends Fragment {


    public FragmentBienvenida() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_bienvenida, container, false);
        ConstraintLayout constraintLayout = view.findViewById(R.id.fragment_bienvenida);
        Button buttonMySongs = view.findViewById(R.id.fragment_bienvenida_button_mySongs);
        buttonMySongs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentRecyclerViewCanciones fragmentRecyclerViewCanciones = new FragmentRecyclerViewCanciones();
                FragmentManager fragmentManager = getFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.main_fragment_layout,fragmentRecyclerViewCanciones);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });
        Button buttonMyAlarms = view.findViewById(R.id.fragment_bienvenida_button_myAlarms);
        buttonMyAlarms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(), "This section will be available very soon!", Toast.LENGTH_LONG).show();
            }
        });

        return view;
    }

}
