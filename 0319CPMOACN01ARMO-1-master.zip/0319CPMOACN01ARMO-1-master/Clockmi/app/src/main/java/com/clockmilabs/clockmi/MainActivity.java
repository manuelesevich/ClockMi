package com.clockmilabs.clockmi;

import android.animation.Animator;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements FragmentRecyclerViewCanciones.ListenerCancionSeleccionada {

    public static final String TAG_FRAGMENT_INICIO = "fragmentInicio";
    public static final String TAG_NO_FRAGMENT_INICIO = "otroFragmentQueNoEsElDeInicio";


    ImageView bgapp, clover;
    ImageView imagelogo;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bgapp = findViewById(R.id.bgapp);
        clover = findViewById(R.id.clover);
        imagelogo = findViewById(R.id.logo);


        bgapp.animate().translationY(-2700).setDuration(1500).setStartDelay(100);
        clover.animate().alpha(0).setDuration(200).setStartDelay(900);
        imagelogo.animate().translationY(140).alpha(0).setDuration(400).setStartDelay(900).setListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {

            }

            @Override
            public void onAnimationEnd(Animator animation) {
                /*FragmentBienvenida fragmentBienvenida = new FragmentBienvenida();
                pegarFragment(fragmentBienvenida, TAG_FRAGMENT_INICIO);*/

                FragmentLogIn fragmentLogIn = new FragmentLogIn();
                pegarFragment(fragmentLogIn, TAG_FRAGMENT_INICIO);
            }

            @Override
            public void onAnimationCancel(Animator animation) {

            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }
        });







    }



    @Override
    public void cancionSeleccionada(Cancion cancion) {

//        Bundle bundle = new Bundle();
//        FragmentDetalle fragmentDetalle = new FragmentDetalle();
//        bundle.putSerializable(FragmentDetalle.Key_Cancion,cancion);
//        fragmentDetalle.setArguments(bundle);
//        pegarFragment(fragmentDetalle, TAG_NO_FRAGMENT_INICIO);

        FragmentViewpagerDetalleCanciones fragmentViewpagerDetalleCanciones = new FragmentViewpagerDetalleCanciones();
        pegarFragment(fragmentViewpagerDetalleCanciones, TAG_NO_FRAGMENT_INICIO);
        Bundle bundle = new Bundle();
        bundle.putSerializable(FragmentViewpagerDetalleCanciones.KEY_CANCION_DETALLE, cancion);
        fragmentViewpagerDetalleCanciones.setArguments(bundle);
    }
    public void pegarFragment(Fragment fragment, String tag){

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.main_fragment_layout,fragment);
        if (!tag.equals(TAG_FRAGMENT_INICIO)){
            fragmentTransaction.addToBackStack(null);
        }
        fragmentTransaction.commit();
    }
}
