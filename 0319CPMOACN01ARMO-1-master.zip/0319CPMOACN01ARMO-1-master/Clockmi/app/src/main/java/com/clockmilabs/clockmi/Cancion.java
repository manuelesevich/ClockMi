package com.clockmilabs.clockmi;

import java.io.Serializable;

public class Cancion implements Serializable {

    private String tituloCancion;
    private String compositor;
    private Integer reproducciones;
    private Integer imagen;

    public Cancion(String tituloCancion, String compositor, Integer descargas, Integer imagen) {
        this.tituloCancion = tituloCancion;
        this.compositor = compositor;
        this.reproducciones = descargas;
        this.imagen = imagen;
    }

    public String getTituloCancion() {
        return tituloCancion;
    }

    public String getCompositor() {
        return compositor;
    }

    public Integer getReproducciones() {
        return reproducciones;
    }

    public Integer getImagen() {
        return imagen;
    }
}
