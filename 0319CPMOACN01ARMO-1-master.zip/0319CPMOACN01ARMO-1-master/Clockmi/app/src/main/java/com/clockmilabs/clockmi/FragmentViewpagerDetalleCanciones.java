package com.clockmilabs.clockmi;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentViewpagerDetalleCanciones extends Fragment {

    public static final String KEY_CANCION_DETALLE = "cancionSeleccionada";


    public FragmentViewpagerDetalleCanciones() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_viewpager_detalle_canciones, container, false);

        Bundle bundle = getArguments();
        Cancion cancion = (Cancion) bundle.getSerializable(KEY_CANCION_DETALLE);

        ViewPager viewPager = view.findViewById(R.id.viewpager_detalle_canciones);
        ViewpagerDetalleCancionesAdapter viewpagerDetalleCancionesAdapter = new ViewpagerDetalleCancionesAdapter(getFragmentManager(), CargarCancion(), cancion );
        viewPager.setAdapter(viewpagerDetalleCancionesAdapter);

        viewPager.setCurrentItem(viewpagerDetalleCancionesAdapter.getIndiceCancionSeleccionada());

        return view;
    }

    public List<Cancion> CargarCancion(){

        List<Cancion>canciones = new ArrayList<>();
        canciones.add(new Cancion("Sand Storm","Darude",200,R.drawable.sandstorm));
        canciones.add(new Cancion("The Day That Never Comes","Metallica",1000,R.drawable.metallica));
        canciones.add(new Cancion("Hard Days Night","Beatles", 950,R.drawable.beatle));
        canciones.add(new Cancion("Pasos Al Costado","Turf", 234,R.drawable.turf));
        canciones.add(new Cancion("Under Pressure", "Queen",2000,R.drawable.queen));
        canciones.add(new Cancion("Cant Stop","Red Hot Chilli Peppers", 460,R.drawable.rhcp));
        canciones.add(new Cancion("Boca Yo Te Amo","Mc Caco",6000,R.drawable.boca));
        canciones.add(new Cancion("Pipes Of Peace","Paul Mccartney", 2400,R.drawable.paulma));
        canciones.add(new Cancion("Imagine","John Lennon",3500,R.drawable.imagine));
        canciones.add(new Cancion("Cum on Feel The Noise","Twisted Sisters", 300,R.drawable.twistedsister));
        canciones.add(new Cancion("Dream On","AeroSmith",2100,R.drawable.dreamon));

        return canciones;
    }

}
