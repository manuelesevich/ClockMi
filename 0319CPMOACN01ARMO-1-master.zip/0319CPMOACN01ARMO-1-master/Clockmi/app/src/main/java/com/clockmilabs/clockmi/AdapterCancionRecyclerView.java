package com.clockmilabs.clockmi;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class AdapterCancionRecyclerView extends RecyclerView.Adapter<AdapterCancionRecyclerView.CancionViewHolder> {

    private List<Cancion>canciones;
    private CancionSeleccionadaListener cancionSeleccionadaListener;

    public AdapterCancionRecyclerView(List<Cancion> canciones, CancionSeleccionadaListener cancionSeleccionadaListener) {
        this.canciones = canciones;
        this.cancionSeleccionadaListener = cancionSeleccionadaListener;
    }

    @NonNull
    @Override
    public CancionViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.celdacancion,viewGroup,false);
        CancionViewHolder cancionViewHolder= new CancionViewHolder(view);
        return cancionViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull CancionViewHolder cancionViewHolder, int i) {

        Cancion cancion = canciones.get(i);
       cancionViewHolder.bindCancion(cancion);

    }

    @Override
    public int getItemCount() {
        return canciones.size();
    }

    public class CancionViewHolder extends RecyclerView.ViewHolder{

        private ImageView imagen;
        private TextView  titulo;
        private TextView  compositor;
        private TextView  descargas;

        public CancionViewHolder(@NonNull final View itemView) {
            super(itemView);
            this.imagen = itemView.findViewById(R.id.celda_cancion_imagen);
            this.titulo = itemView.findViewById(R.id.celda_cancion_textview_titulo);
            this.compositor = itemView.findViewById(R.id.celda_cancion_textview_compositor);
            this.descargas = itemView.findViewById(R.id.celda_cancion_textview_alarmas);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Cancion cancion = canciones.get(getAdapterPosition());
                    cancionSeleccionadaListener.cancionSeleccionada(cancion);


                }
            });
        }

        public void bindCancion(Cancion cancion){

            titulo.setText(cancion.getTituloCancion());
            imagen.setImageResource(cancion.getImagen());
            compositor.setText(cancion.getCompositor());
            descargas.setText(cancion.getReproducciones().toString());


        }


    }


    public interface CancionSeleccionadaListener{

        public void cancionSeleccionada(Cancion cancion);
    }



}
