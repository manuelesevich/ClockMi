package com.clockmilabs.clockmi;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentDetalle extends Fragment {

    public static final String Key_Cancion = "Cancion";
    private boolean play = false;


    public static FragmentDetalle fragmentDetalleFactory(Cancion cancion){

        FragmentDetalle fragmentDetalle = new FragmentDetalle();
        Bundle bundle = new Bundle();
        bundle.putSerializable(Key_Cancion, cancion);
        fragmentDetalle.setArguments(bundle);

        return fragmentDetalle;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_detalle, container, false);
        Bundle bundle = getArguments();
        Cancion cancion = (Cancion) bundle.getSerializable(Key_Cancion);
        final ImageButton imageButtonPlay = view.findViewById(R.id.fragment_detalle_boton_reproducir);
        ImageView imageViewImagen = view.findViewById(R.id.fragment_detalle_imagen_de_cancion);
        TextView textViewTitulo = view.findViewById(R.id.fragment_detalle_texview_titulocancion);
        TextView textViewCompositor = view.findViewById(R.id.fragment_detalle_textview_compositor);
        imageViewImagen.setImageResource(cancion.getImagen());
        textViewTitulo.setText(cancion.getTituloCancion());
        textViewCompositor.setText(cancion.getCompositor());
        imageButtonPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (play == true)
                {
                    imageButtonPlay.setImageResource(R.drawable.pausesong);
                    play = false;
                }
                else if (play == false)
                {
                    imageButtonPlay.setImageResource(R.drawable.playbutton);
                    play = true;
                }

            }
        });
        return view;


    }

}
