package com.clockmilabs.clockmi;


import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentRecyclerViewCanciones extends Fragment implements AdapterCancionRecyclerView.CancionSeleccionadaListener {

    private ListenerCancionSeleccionada listenerCancionSeleccionada;







    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_recycler_view_canciones, container, false);
        RecyclerView recyclerView = view.findViewById(R.id.fragment_recyclerview_listaitems);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(),LinearLayoutManager.VERTICAL,false));
        AdapterCancionRecyclerView adapterCancionRecyclerView = new AdapterCancionRecyclerView(CargarCancion(), this);
        recyclerView.setAdapter(adapterCancionRecyclerView);
        return view;


    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        listenerCancionSeleccionada =(ListenerCancionSeleccionada) context;
    }

    public List<Cancion>CargarCancion(){

       List<Cancion>canciones = new ArrayList<>();
       canciones.add(new Cancion("Sand Storm","Darude",200,R.drawable.sandstorm));
       canciones.add(new Cancion("The Day That Never Comes","Metallica",1000,R.drawable.metallica));
       canciones.add(new Cancion("Hard Days Night","Beatles", 950,R.drawable.beatle));
       canciones.add(new Cancion("Pasos Al Costado","Turf", 234,R.drawable.turf));
       canciones.add(new Cancion("Under Pressure", "Queen",2000,R.drawable.queen));
       canciones.add(new Cancion("Cant Stop","Red Hot Chilli Peppers", 460,R.drawable.rhcp));
       canciones.add(new Cancion("Boca Yo Te Amo","Mc Caco",6000,R.drawable.boca));
       canciones.add(new Cancion("Pipes Of Peace","Paul Mccartney", 2400,R.drawable.paulma));
       canciones.add(new Cancion("Imagine","John Lennon",3500,R.drawable.imagine));
       canciones.add(new Cancion("Cum on Feel The Noise","Twisted Sisters", 300,R.drawable.twistedsister));
       canciones.add(new Cancion("Dream On","AeroSmith",2100,R.drawable.dreamon));

       return canciones;



    }

    @Override
    public void cancionSeleccionada(Cancion cancion) {

        listenerCancionSeleccionada.cancionSeleccionada(cancion);

    }
    public interface ListenerCancionSeleccionada{
        public void cancionSeleccionada(Cancion cancion);
    }
}
