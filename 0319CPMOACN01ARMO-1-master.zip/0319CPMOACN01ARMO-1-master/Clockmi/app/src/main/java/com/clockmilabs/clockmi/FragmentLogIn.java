package com.clockmilabs.clockmi;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentLogIn extends Fragment {


    public FragmentLogIn() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_log_in, container, false);

        ImageButton imageButtonFacebook = view.findViewById(R.id.fragment_log_in_imagebutton_facebook);
        imageButtonFacebook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentBienvenida fragmentBienvenida = new FragmentBienvenida();
                pegarFragment(fragmentBienvenida, MainActivity.TAG_NO_FRAGMENT_INICIO);

            }
        });

        ImageButton imageButtonGoogle = view.findViewById(R.id.fragment_log_in_imagebutton_google);
        imageButtonGoogle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentBienvenida fragmentBienvenida = new FragmentBienvenida();
                pegarFragment(fragmentBienvenida, MainActivity.TAG_NO_FRAGMENT_INICIO);
            }
        });

        return view;
    }

    public void pegarFragment(Fragment fragment, String tag){

        FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.main_fragment_layout,fragment);
        if (!tag.equals(MainActivity.TAG_FRAGMENT_INICIO)){
            fragmentTransaction.addToBackStack(null);
        }
        fragmentTransaction.commit();
    }

}
