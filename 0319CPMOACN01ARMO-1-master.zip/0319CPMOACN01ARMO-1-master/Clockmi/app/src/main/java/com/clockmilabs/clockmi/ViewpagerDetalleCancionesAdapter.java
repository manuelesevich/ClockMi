package com.clockmilabs.clockmi;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import java.util.ArrayList;
import java.util.List;

public class ViewpagerDetalleCancionesAdapter extends FragmentStatePagerAdapter {

    private List<FragmentDetalle> listaFragmentDetalle;
    private int indiceCancionSeleccionada;

    public ViewpagerDetalleCancionesAdapter(FragmentManager fm, List<Cancion> listaDeCanciones, Cancion cancionSeleccionada) {
        super(fm);
        listaFragmentDetalle = new ArrayList<>();

        for (Cancion cancion : listaDeCanciones){
            FragmentDetalle fragmentDetalle = FragmentDetalle.fragmentDetalleFactory(cancion);
            listaFragmentDetalle.add(fragmentDetalle);
            if(cancion.getTituloCancion().equals(cancionSeleccionada.getTituloCancion())){
                indiceCancionSeleccionada = listaFragmentDetalle.indexOf(fragmentDetalle);
            }
        }
    }


    @Override
    public Fragment getItem(int i) {
        return listaFragmentDetalle.get(i);
    }

    @Override
    public int getCount() {
        return listaFragmentDetalle.size();
    }

    public int getIndiceCancionSeleccionada() {
        return indiceCancionSeleccionada;
    }
}
